<?php include('header.php')?>

  <main id="content" class="content bg-black" data-liquid-stack="true" data-stack-options="{&quot;navigation&quot;:false,&quot;prevNextButtons&quot;:true,&quot;pageNumber&quot;:true,&quot;prevNextLabels&quot;:{&quot;prev&quot;:&quot;Previous&quot;,&quot;next&quot;:&quot;Next&quot;},&quot;effect&quot;:&quot;fadeScale&quot;, &quot;disableOnMobile&quot;: false}" style="overflow: hidden; touch-action: none;">
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_sw pp-scrollable pp-section" data-anchor="Section-1" style="z-index: 11; transform: translate3d(0px, -100%, 0px); background:linear-gradient(rgb(0 0 0) 0%, rgb(66, 62, 232) 100%)">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-3" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                                    <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#19d4ac&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 1; transform: scale(1);">
                                                            <img src="assets/img/mobile/mobiledevloper.gif" alt=" Customized Software Development Company in Moradabad">
                                                        </figure>
                                                    </div>
                                                    <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 100% 50%; background: rgb(66, 19, 219); opacity: 1;"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h1 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }" style="margin-bottom:4px">
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="Software" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="S" class="split-inner"><span class="split-txt">S</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="f" class="split-inner"><span class="split-txt">f</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="w" class="split-inner"><span class="split-txt">w</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="a" class="split-inner"><span class="split-txt">a</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="r" class="split-inner"><span class="split-txt">r</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="Development" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="D" class="split-inner"><span class="split-txt">D</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="v" class="split-inner"><span class="split-txt">v</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                </h1>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech Technology, a leading software " class="split-inner"><span class="split-txt">GrootTech Technology, a leading software </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="development company with offices in Gurgaon, " class="split-inner"><span class="split-txt">development company with offices in Gurgaon, </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="India and the United States, provides " class="split-inner"><span class="split-txt">India and the United States, provides </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="organisations with tailored software, corporate " class="split-inner"><span class="split-txt">organisations with tailored software, corporate </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="solutions, CRM solutions and SaaS-based " class="split-inner"><span class="split-txt">solutions, CRM solutions and SaaS-based </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="development services. Our experienced team " class="split-inner"><span class="split-txt">development services. Our experienced team </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="uses cutting-edge tools and techniques to craft " class="split-inner"><span class="split-txt">uses cutting-edge tools and techniques to craft </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="innovative yet customer-focused software " class="split-inner"><span class="split-txt">innovative yet customer-focused software </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="applications for various industries." class="split-inner"><span class="split-txt">applications for various industries.</span></span></div>
                                                </p>
                                                <a href="software-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Software development End-->

<style>
                @media screen and (max-width: 1199px) {
    [data-mobile-nav-trigger-alignment=right] .navbar-header .navbar-brand-inner {
        margin-right: 23px !important;
    }
}
</style>
                <!--Mobile App development start--> 
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_mobapp pp-scrollable pp-section" data-anchor="Section-2" style="z-index: 10; transform: translate3d(0px, -100%, 0px);
                background:linear-gradient(to bottom, #000000 0%,rgb(225, 177, 4) 100%)">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-4" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                                    <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#fdf4e9&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 1; transform: scale(1);"> <img src="assets/img/mobile/softwaredeveloper.gif" alt="App Development Company in Moradabad"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 0px 50%; background: rgb(253, 244, 233); opacity: 1;"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="Mobile" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="M" class="split-inner"><span class="split-txt">M</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="b" class="split-inner"><span class="split-txt">b</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="i" class="split-inner"><span class="split-txt">i</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="App" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="A" class="split-inner"><span class="split-txt">A</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="Development" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="D" class="split-inner"><span class="split-txt">D</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="v" class="split-inner"><span class="split-txt">v</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                </h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech's expert services offer custom " class="split-inner"><span class="split-txt">GrootTech's expert services offer custom </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="development of various mobile applications for " class="split-inner"><span class="split-txt">development of various mobile applications for </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="all kinds of OS platforms, such as Android, iOS " class="split-inner"><span class="split-txt">all kinds of OS platforms, such as Android, iOS </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="and Windows. Get your own customized mobile " class="split-inner"><span class="split-txt">and Windows. Get your own customized mobile </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="apps to ensure the success strategy of your " class="split-inner"><span class="split-txt">apps to ensure the success strategy of your </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="business, because these apps play an effective " class="split-inner"><span class="split-txt">business, because these apps play an effective </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="instrumental role to achieve digital interaction." class="split-inner"><span class="split-txt">instrumental role to achieve digital interaction.</span></span></div>
                                                </p>
                                                <a href="mobile-app-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Mobile App development End-->
                <!-- Ecommerce solutions start-->  
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_ecs pp-scrollable pp-section active" data-anchor="Section-3" style="z-index: 9; transform: translate3d(0px, 0px, 0px); background:linear-gradient(to bottom, #000000 0%, #f100a7 100%)">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                                    <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#066DAB&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 1; transform: scale(1);"> <img src="assets/img/mobile/ecommerce.gif" alt="Ecommerce Development Company in Moradabad"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 100% 50%; background: rgb(6, 109, 171); opacity: 1;"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="eCommerce" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="C" class="split-inner"><span class="split-txt">C</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="r" class="split-inner"><span class="split-txt">r</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="c" class="split-inner"><span class="split-txt">c</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="Solutions" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="S" class="split-inner"><span class="split-txt">S</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="u" class="split-inner"><span class="split-txt">u</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="i" class="split-inner"><span class="split-txt">i</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="s" class="split-inner"><span class="split-txt">s</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                </h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech offers e-commerce solutions to " class="split-inner"><span class="split-txt">GrootTech offers e-commerce solutions to </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="maximize your revenues and consumer " class="split-inner"><span class="split-txt">maximize your revenues and consumer </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="engagement. We help you lower your costs and " class="split-inner"><span class="split-txt">engagement. We help you lower your costs and </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="optimize your web presence for the highest " class="split-inner"><span class="split-txt">optimize your web presence for the highest </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="possible return on investment. We do this by " class="split-inner"><span class="split-txt">possible return on investment. We do this by </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="building a web presence over multiple channels " class="split-inner"><span class="split-txt">building a web presence over multiple channels </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="and giving you the tools required to understand " class="split-inner"><span class="split-txt">and giving you the tools required to understand </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="your target demographic." class="split-inner"><span class="split-txt">your target demographic.</span></span></div>
                                                </p>
                                                <a href="ecommerce-development-company-gurgaon.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Ecommerce solutions End--> 
                <!-- Web development start--> 
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_wd pp-scrollable pp-section" data-anchor="Section-4" style="z-index: 8; transform: translate3d(0px, 0px, 0px);background:linear-gradient(to bottom, #000000 0%,#233b4f 100%)">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-2" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                                    <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#233b4f&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 1; transform: scale(1);"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/webdevelopment-new.gif" alt=" Custom Web Development Company in Moradabad"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 0px 50%; background: rgb(35, 59, 79); opacity: 1;"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="Web" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="W" class="split-inner"><span class="split-txt">W</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="b" class="split-inner"><span class="split-txt">b</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                                        <span data-text="Development" class="split-inner">
                                                            <span class="split-txt">
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="D" class="split-inner"><span class="split-txt">D</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="v" class="split-inner"><span class="split-txt">v</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                                <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                            </span>
                                                        </span>
                                                    </div>
                                                </h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech offers better web development solution " class="split-inner"><span class="split-txt">GrootTech offers better web development solution </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="than any exclusive web development company. " class="split-inner"><span class="split-txt">than any exclusive web development company. </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="With our full range of custom designs, " class="split-inner"><span class="split-txt">With our full range of custom designs, </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="user-friendly web layout, and fluid coding, we " class="split-inner"><span class="split-txt">user-friendly web layout, and fluid coding, we </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="give you the best web development services. We " class="split-inner"><span class="split-txt">give you the best web development services. We </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="value client reviews and requirements. We tailor " class="split-inner"><span class="split-txt">value client reviews and requirements. We tailor </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="every webpage to suit your exact needs. Tell us " class="split-inner"><span class="split-txt">every webpage to suit your exact needs. Tell us </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="what you want from your website, and we will " class="split-inner"><span class="split-txt">what you want from your website, and we will </span></span></div>
                                                <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="make it happen for you. " class="split-inner"><span class="split-txt">make it happen for you. </span></span></div>
                                                </p>
                                                <a href="web-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Web development End-->   
                <!-- UI/UX/Creative/Graphics-->
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_uiux pp-scrollable pp-section" data-anchor="Section-5" style="z-index: 7; transform: translate3d(0px, 0px, 0px);background:linear-gradient(to bottom, #000000 0%,#444c4f 100%)!important;">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-1" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#444c4f&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/ui-ux-new.gif" alt="Best UI UX Development Company in Moradabad, India"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">UI/UX Design</h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech offers businesses cutting-edge graphics and creative design services. Utilizing the most up-to-date tools and design trends, our experienced team produces visually appealing and captivating graphics such as logos, brochures, flyers, and infographics that convey a brand's values and personality while leaving an impactful visual.
                                                    Make an impression on your target audience
                                                </p>
                                                <a href="uiux-design.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- UI/UX/Creative/Graphics End-->
                <!-- Digital Marketing start--> 
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_dm pp-scrollable pp-section" data-anchor="Section-6" style="z-index: 6; transform: translate3d(0px, 0px, 0px);background:linear-gradient(to bottom, #000000 0%,#3faccf  100%)!important; ">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#0a0102&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 0;"> <img src="https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExcTkxdnoxMXpncm1paHJxa2prYm5ucDZwZmF0c2d0cG4zcjk2YzR0MiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/gHiRWOaXGGHOY5w6f3/giphy.gif" alt="Best Digital Marketing Company in Moradabad, India"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Digital Marketing</h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">Not business stands a chance without Digital Marketing anymore. There are way too many digital marketing companies claiming to be the best. But GrootTech believes in proving it is the best for you. With custom digital marketing plans and organic strategies, we ensure you value for your money. We will ensure that the returns are worth the investment. </p>
                                                <a href="digital-marketing-services.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Digital Marketing End--> 
                <!-- Artificial Intelligence  start--> 
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_ai pp-scrollable pp-section" data-anchor="Section-7" style="z-index: 5; transform: translate3d(0px, 0px, 0px);">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-4" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#333&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/ai-new.gif" alt="Artificial Intelligence services in Gurgaon"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Artificial Intelligence</h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech's Artificial Intelligence service offers you the insight your business needs for long-term and immediate success. All pain points in your business are identified by GrootTech's advanced AI systems. GrootTech offers user-friendly AI solutions so that every client can take it for a run. We want you to witness the groundbreaking solutions our AI team offers.  </p>
                                                <a href="artificial-intelligence.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Artificial IntelligenceEnd-->
                <!-- Blockchain Development start--> 
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_bcd pp-scrollable pp-section" data-anchor="Section-8" style="z-index: 4; transform: translate3d(0px, 0px, 0px);background:linear-gradient(to bottom, #000000 0%,#20b7eb  100%)!important;">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-2" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#0996c7&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/blockchain-new.gif" alt=" Reliable Blockchain development
                                                            Company in Moradabad"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Blockchain Development</h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech provides a stable and systematically updated Blockchain infrastructure for cryptocurrency. With GrootTech's independent Blockchain development platform, your cryptocurrency will be safe from censorship and collusion alike. No other Blockchain development company can ensure smooth and safe business with cryptocurrency like GrootTech does.</p>
                                                <a href="blockchain-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Blockchain development End-->    
                <!-- Big Data start-->  
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_bd pp-scrollable pp-section" data-anchor="Section-9" style="z-index: 3; transform: translate3d(0px, 0px, 0px);">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(68, 76, 79, 0.1)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#000&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/big-data-new.gif" alt=" Renowned Big Data Company in Moradabad"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Big Data</h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech's Big Data service helps you accurately analyze bulk data. Our robust infrastructure helps create detailed reports including business metrics analysis. You can analyze all sorts of files and feeds that you upload. Cloud databases, online or offline applications, custom applications, nothing is out of bounds for GrootTech's Big Data company. </p>
                                                <a href="big-data.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Big Data  End--> 
                <!-- Internet of things  start-->  
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_iot pp-scrollable pp-section" data-anchor="Section-10" style="z-index: 2; transform: translate3d(0px, 0px, 0px);background:linear-gradient(to bottom, #000000 0%,#20b7eb  100%)!important;">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#d7f1fb&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/iot-new.gif" alt="IoT services"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Internet of things</h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech offers IoT services that will introduce your lifestyle to the future. You can initiate smart living with all your devices synced and running on the IoT principle. GrootTech has IoT solutions for every device that is important in your daily routine. Include as many functional devices you want to on your IoT systems. You tell us how much convenience you need and we will serve it to you on a plate. </p>
                                                <a href="iot.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--Internet of things   End-->    
                <!-- Our Clients start--> 
                <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_clients pp-scrollable pp-section" data-anchor="Section-11" style="z-index: 1; transform: translate3d(0px, 0px, 0px);background:linear-gradient(to bottom, #000000 0%,#444661  100%)!important;">
                    <div class="lqd-stack-section-inner">
                        <div class="lqd-particles-bg-wrap">
                            <div class="ld-particles-container">
                                <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                                    <div class="lqd-promo-wrap text-white">
                                        <div class="lqd-promo-inner">
                                            <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                                <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                                    <path d="
                                                        M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                                        M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                                        M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                                </svg>
                                            </div>
                                            <div class="lqd-promo-cat">
                                                <ul class="reset-ul">
                                                </ul>
                                            </div>
                                            <div class="lqd-promo-img">
                                                <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#444661&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                                    <div class="block-revealer__content">
                                                        <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/clients-new.gif" alt="Clients of GrootTech"> </figure>
                                                    </div>
                                                    <div class="block-revealer__element"></div>
                                                </div>
                                            </div>
                                            <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                                <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Our Clients</h2>
                                                <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech has built a large portfolio with different industries operating across the globe,our major clients are in North America,Europe and APAC region . Our quality work and end to end solution capabilities help in strengthening the long term partnership with the GrootTech team.</p>
                                                <a href="clients.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Clients</span> </span> </a> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Our Clients End-->
            </main>
        </div>
        <!-- Overlay Menu Start Here-->
        <div id="myNav" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
            <div class="overlay-content">
                <!-- Menu Tabs Start here-->
                <div class="menu_box">
                    <div class="col-xs-3">
                        <!-- required for floating -->
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs tabs-left">
                            <li class="active"><a href="#sw" data-toggle="tab">
                                <span class="hidden-xs">Software Development</span> 
                                <i class="flaticon flaticon-computer" title="Software Development"></i>
                                </a>
                            </li>
                            <li><a href="#mad" data-toggle="tab">
                                <span class="hidden-xs">Mobile App Development </span>
                                <i class="flaticon flaticon-app" title="Mobile App Development"></i>
                                </a>
                            </li>
                            <li><a href="#wd" data-toggle="tab">
                                <span class="hidden-xs">Web Development </span>
                                <i class="flaticon flaticon-data" title="Web Development "></i>
                                </a>
                            </li>
                            <li><a href="#uiux" data-toggle="tab">
                                <span class="hidden-xs">Artificial Intelligence </span>
                                <i class="flaticon flaticon-brain" title="UI/UX/Creative/Graphics"></i>
                                </a>
                            </li>
                            <li><a href="#ecd" data-toggle="tab">
                                <span class="hidden-xs">E-Commerce Solutions </span>
                                <i class="flaticon flaticon-monitor" title="E-Commerce Solutions "></i>
                                </a>
                            </li>
                            <li><a href="#Staff" data-toggle="tab">
                                <span class="hidden-xs">Staff Augmentation </span>
                                <i class="flaticon flaticon-monitor" title="Staff Augmentation"></i>
                                </a>
                            </li>
                            <li><a href="#industry" data-toggle="tab">
                                <span class="hidden-xs">Industry </span>
                                <i class="flaticon flaticon-security" title="Industry"></i>
                                </a>
                            </li>
                            <li><a href="#resource" data-toggle="tab">
                                <span class="hidden-xs">Resources  </span>
                                <i class="flaticon flaticon-people" title="Resources"></i>
                                </a>
                            </li>
                            <li><a href="#compinfo" data-toggle="tab">
                                <span class="hidden-xs">Company Info.</span>  
                                <i class="flaticon flaticon-construction" title="Company Info."></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-xs-9">
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="sw">
                                <h2><a href="software-development.php">Software Development</a> </h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="software-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Custom Software <br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="software-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-ux"></i>Enterprise <br>Solutions</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="software-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-digital-marketing"></i>CRM <br>Solutions</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="mad">
                                <h2><a href="mobile-app-development.php">Mobile App Development</a></h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="https://www.GrootTech.com/ios-app-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>IOS<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="https://www.GrootTech.com/android-app-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-ux"></i>Android  <br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="https://www.GrootTech.com/native-app-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Native  <br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="https://www.GrootTech.com/hybrid-app-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Hybrid App <br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="wd">
                                <h2><a href="web-development.php">Web Development</a> </h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="web-development-technology.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Website Development Technologies</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="custom-website-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-ux"></i>Custom Website<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="dyanamic-website-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Dynamic Website <br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="static-website-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Static Website <br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="full-stack-website-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-ux"></i>Full Stack Website<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="ai-powered-website-development.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Ai Powered Website<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="uiux">
                                <h2><a href="artificial-intelligence.php">Artificial Intelligence</a></h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="deep-learning.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-data"></i>Deep Learning &amp;<br>Data Science</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="integrated-intelligence-services.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-pencil"></i>Integrated Intelligence<br> Services</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="computer-vision-technology.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-computer"></i>Computer Vision <br>Technology Services</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="3d-and-metaverse-based.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-computer-1"></i>3D and Metaverse-based</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="pioneering-generative-ai-integration.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-security"></i>Generative AI Integration Solutions</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="ecd">
                                <h2><a href="ecommerce-solutions-in-gurgaon.php">E-Commerce Solutions</a></h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="magento-development-company-india.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Magento<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="opencart-development-company-india.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Opencart<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="shopify-development-company-india.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Shopify<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="woocommerce-development-company-india.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>WooCommerce<br>Development</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="Staff">
                                <h2><a href="staff-augmentation-services.php">Staff Augmentation Services</a></h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="staff-augmentation-services.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Staff<br>Augmentation Services</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="industry">
                                <h2><a href="industry-landing.php">Industry</a></h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	Banking and <br>Finance</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	Tour and <br>Travels </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	Real Estate and <br>Construction  </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	E-Commerce /<br> Retail</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	Automobile</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	Health and <br>Social Care</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	Education and <br>Career </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="industry.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>	Arts and <br>Entertainment </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="resource">
                                <h2><a href="resources.php">Resources</a></h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="blog">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Blogs</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="resources.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-chart"></i>Case Studies</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="compinfo">
                                <h2>Company Information</h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <a href="about.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-construction"></i>About Company</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="clients.php">
                                            <div class="box_1">
                                                <div class="text"><i class="fa fa-group"></i>Our Clients</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="contact.php">
                                            <div class="box_1">
                                                <div class="text"><i class="flaticon flaticon-email"></i>Get In Touch</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="career.php">
                                            <div class="box_1">
                                                <div class="text"><i class="fa fa-plane"></i>Career</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Menu Tabs End here-->
                </div>
            </div>
        </div>
        <!-- Overlay Menu Start End-->
        <script src="/assets/vendors/modernizr.min.js"></script>
        <script src="assets/vendors/jquery.min.js"></script>
        <script src="assets/js/theme-vendors.min.js"></script>
        <script src="assets/vendors/pagePiling/dist/jquery.pagepiling.min.js"></script>
        <script src="assets/js/theme.min.js"></script>
        <script src="assets/js/ambi-custom.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/slick.js"></script>
        <script src="assets/js/slick-responsive.js"></script>  <a href="https://api.whatsapp.com/send?phone=919917864981" class="whatsapp_btn">
        <img src="assets/img/whatsapp.png" alt="whatsapp">
        </a>
        <style type="text/css">
            .whatsapp_btn{
            position: fixed;bottom: 16px; right: 16px; width: 40px;height: 40px;  
            border-radius: 10px;z-index: 9999;
            -webkit-box-shadow: 3px 3px 6px rgba(0,0,0,0.5);
            -moz-box-shadow: 3px 3px 6px rgba(0,0,0,0.5);
            box-shadow: 3px 3px 6px rgba(0,0,0,0.5);
            -webkit-box-sizing:border-box;
            -moz-box-sizing:border-box;
            -ms-box-sizing:border-box;
            box-sizing:border-box;
            }
            .whatsapp_btn:hover{
            -webkit-box-shadow: 5px 5px 5px rgba(0,0,0,0.5);
            -moz-box-shadow: 5px 5px 5px rgba(0,0,0,0.5);
            box-shadow: 5px 5px 5px rgba(0,0,0,0.5);
            }
            .whatsapp_btn img{display: block;width: auto;max-width: 100%}
            @media (max-width: 767px){
            .whatsapp_btn{display: block;}
            }
        </style>
       <?php include('footer.php')?>