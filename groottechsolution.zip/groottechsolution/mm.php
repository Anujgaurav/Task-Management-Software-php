<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="theme-color" content="#3ed2a7">
        <link rel="shortcut icon" href="assets/img/logoanu.png">
        <title>Groot Tech solution</title>
        <meta name="description" content="">
        <meta property="og:locale" content="en_US">
        <meta property="og:type" content="website">
        <meta property="og:title" content="">
        <meta property="og:url" content="#">
        <meta property="og:description" content="">
        <meta property="og:image" content="https://www.GrootTech.com//assets/img/sw-development.gif">
        <meta property="og:site_name" content="GrootTech Technology">
        <meta name="twitter:card" content="summary">
        <meta name="twitter:site" content="@GrootTechtek">
        <meta name="twitter:title" content="Software Company in Moradabad | India | USA">
        <meta name="twitter:description" content="Best software company in India, based out in Moradabad. with certified and experience developers we spans our expertise across CRM, SaaS, system software, utility software, application software, DevOps and AI-powered software solutions. Experience the power of tailored, custom software development that  meets your specific business requirements.">
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/themes/multiconcept.css">
        <link rel="stylesheet" href="assets/vendors/liquid-icon/liquid-icon.min.css">
        <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/font/flaticon.css">
        <link rel="stylesheet" href="assets/css/theme-vendors.min.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
        <link rel="stylesheet" href="assets/css/theme.min.css">
        <link rel="stylesheet" href="assets/css/themes/wave.css">
        <link rel="stylesheet" href="assets/css/custom.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/slick.css" async="">
        <link rel="stylesheet" href="assets/css/slick-theme.css">
        <script async="" src="https://www.googletagmanager.com/gtag/js?id=G-8W111Y0YG1"></script>
        <style>
            @media screen and (max-width: 1199px) {
    [data-mobile-nav-trigger-alignment=right] .navbar-header .navbar-brand-inner {
        margin-right: 15px !important;
    }
}
        </style>
    </head>
<main id="content" class="content bg-black" data-liquid-stack="true" data-stack-options="{&quot;navigation&quot;:false,&quot;prevNextButtons&quot;:true,&quot;pageNumber&quot;:true,&quot;prevNextLabels&quot;:{&quot;prev&quot;:&quot;Previous&quot;,&quot;next&quot;:&quot;Next&quot;},&quot;effect&quot;:&quot;fadeScale&quot;, &quot;disableOnMobile&quot;: false}" style="overflow: hidden; touch-action: none;">
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_sw pp-scrollable pp-section" data-anchor="Section-1" style="z-index: 11; transform: translate3d(0px, -100%, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-3" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                        <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#19d4ac&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 1; transform: scale(1);">
                                                <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/sw-development-new.gif" alt=" Customized Software Development Company in Gurgaon">
                                            </figure>
                                        </div>
                                        <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 100% 50%; background: rgb(25, 212, 172); opacity: 1;"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h1 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }" style="margin-bottom:4px">
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="Software" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="S" class="split-inner"><span class="split-txt">S</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="f" class="split-inner"><span class="split-txt">f</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="w" class="split-inner"><span class="split-txt">w</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="a" class="split-inner"><span class="split-txt">a</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="r" class="split-inner"><span class="split-txt">r</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="Development" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="D" class="split-inner"><span class="split-txt">D</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="v" class="split-inner"><span class="split-txt">v</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                    </h1>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech Technology, a leading software " class="split-inner"><span class="split-txt">GrootTech Technology, a leading software </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="development company with offices in Gurgaon, " class="split-inner"><span class="split-txt">development company with offices in Gurgaon, </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="India and the United States, provides " class="split-inner"><span class="split-txt">India and the United States, provides </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="organisations with tailored software, corporate " class="split-inner"><span class="split-txt">organisations with tailored software, corporate </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="solutions, CRM solutions and SaaS-based " class="split-inner"><span class="split-txt">solutions, CRM solutions and SaaS-based </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="development services. Our experienced team " class="split-inner"><span class="split-txt">development services. Our experienced team </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="uses cutting-edge tools and techniques to craft " class="split-inner"><span class="split-txt">uses cutting-edge tools and techniques to craft </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="innovative yet customer-focused software " class="split-inner"><span class="split-txt">innovative yet customer-focused software </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="applications for various industries." class="split-inner"><span class="split-txt">applications for various industries.</span></span></div>
                                    </p>
                                    <a href="software-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Software development End-->
    <!--Mobile App development start--> 
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_mobapp pp-scrollable pp-section" data-anchor="Section-2" style="z-index: 10; transform: translate3d(0px, -100%, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-4" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                        <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#fdf4e9&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 1; transform: scale(1);"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/app-development-new.gif" alt="App Development Company in Gurgaon"> </figure>
                                        </div>
                                        <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 0px 50%; background: rgb(253, 244, 233); opacity: 1;"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="Mobile" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="M" class="split-inner"><span class="split-txt">M</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="b" class="split-inner"><span class="split-txt">b</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="i" class="split-inner"><span class="split-txt">i</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="App" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="A" class="split-inner"><span class="split-txt">A</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="Development" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="D" class="split-inner"><span class="split-txt">D</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="v" class="split-inner"><span class="split-txt">v</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                    </h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech's expert services offer custom " class="split-inner"><span class="split-txt">GrootTech's expert services offer custom </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="development of various mobile applications for " class="split-inner"><span class="split-txt">development of various mobile applications for </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="all kinds of OS platforms, such as Android, iOS " class="split-inner"><span class="split-txt">all kinds of OS platforms, such as Android, iOS </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="and Windows. Get your own customized mobile " class="split-inner"><span class="split-txt">and Windows. Get your own customized mobile </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="apps to ensure the success strategy of your " class="split-inner"><span class="split-txt">apps to ensure the success strategy of your </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="business, because these apps play an effective " class="split-inner"><span class="split-txt">business, because these apps play an effective </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="instrumental role to achieve digital interaction." class="split-inner"><span class="split-txt">instrumental role to achieve digital interaction.</span></span></div>
                                    </p>
                                    <a href="mobile-app-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Mobile App development End-->
    <!-- Ecommerce solutions start-->  
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_ecs pp-scrollable pp-section active" data-anchor="Section-3" style="z-index: 9; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                        <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#066DAB&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 1; transform: scale(1);"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/ecommerce.gif" alt="Ecommerce Development Company in Gurgaon"> </figure>
                                        </div>
                                        <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 100% 50%; background: rgb(6, 109, 171); opacity: 1;"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="eCommerce" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="C" class="split-inner"><span class="split-txt">C</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="r" class="split-inner"><span class="split-txt">r</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="c" class="split-inner"><span class="split-txt">c</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="Solutions" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="S" class="split-inner"><span class="split-txt">S</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="u" class="split-inner"><span class="split-txt">u</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="i" class="split-inner"><span class="split-txt">i</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="s" class="split-inner"><span class="split-txt">s</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                    </h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech offers e-commerce solutions to " class="split-inner"><span class="split-txt">GrootTech offers e-commerce solutions to </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="maximize your revenues and consumer " class="split-inner"><span class="split-txt">maximize your revenues and consumer </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="engagement. We help you lower your costs and " class="split-inner"><span class="split-txt">engagement. We help you lower your costs and </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="optimize your web presence for the highest " class="split-inner"><span class="split-txt">optimize your web presence for the highest </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="possible return on investment. We do this by " class="split-inner"><span class="split-txt">possible return on investment. We do this by </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="building a web presence over multiple channels " class="split-inner"><span class="split-txt">building a web presence over multiple channels </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="and giving you the tools required to understand " class="split-inner"><span class="split-txt">and giving you the tools required to understand </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="your target demographic." class="split-inner"><span class="split-txt">your target demographic.</span></span></div>
                                    </p>
                                    <a href="ecommerce-development-company-gurgaon.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Ecommerce solutions End--> 
    <!-- Web development start--> 
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_wd pp-scrollable pp-section" data-anchor="Section-4" style="z-index: 8; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-2" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}">
                        <canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="336" height="498"></canvas>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer element-uncovered revealing-ended" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#233b4f&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 1; transform: scale(1);"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/webdevelopment-new.gif" alt=" Custom Web Development Company in Gurgaon"> </figure>
                                        </div>
                                        <div class="block-revealer__element" style="transform: scaleX(0); transform-origin: 0px 50%; background: rgb(35, 59, 79); opacity: 1;"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content ca-initvalues-applied lqd-animations-done" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white ca-initvalues-applied perspective lqd-animations-done split-text-applied" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="Web" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="W" class="split-inner"><span class="split-txt">W</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="b" class="split-inner"><span class="split-txt">b</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                        <div style="position:relative;display:inline-block;" class="lqd-words split-unit lqd-unit-animation-done">
                                            <span data-text="Development" class="split-inner">
                                                <span class="split-txt">
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="D" class="split-inner"><span class="split-txt">D</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="v" class="split-inner"><span class="split-txt">v</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="l" class="split-inner"><span class="split-txt">l</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="o" class="split-inner"><span class="split-txt">o</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="p" class="split-inner"><span class="split-txt">p</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="m" class="split-inner"><span class="split-txt">m</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="e" class="split-inner"><span class="split-txt">e</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="n" class="split-inner"><span class="split-txt">n</span></span></div>
                                                    <div style="position:relative;display:inline-block;" class="lqd-chars split-unit lqd-unit-animation-done"><span data-text="t" class="split-inner"><span class="split-txt">t</span></span></div>
                                                </span>
                                            </span>
                                        </div>
                                    </h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }" class="ca-initvalues-applied lqd-animations-done split-text-applied" style="">
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="GrootTech offers better web development solution " class="split-inner"><span class="split-txt">GrootTech offers better web development solution </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="than any exclusive web development company. " class="split-inner"><span class="split-txt">than any exclusive web development company. </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="With our full range of custom designs, " class="split-inner"><span class="split-txt">With our full range of custom designs, </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="user-friendly web layout, and fluid coding, we " class="split-inner"><span class="split-txt">user-friendly web layout, and fluid coding, we </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="give you the best web development services. We " class="split-inner"><span class="split-txt">give you the best web development services. We </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="value client reviews and requirements. We tailor " class="split-inner"><span class="split-txt">value client reviews and requirements. We tailor </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="every webpage to suit your exact needs. Tell us " class="split-inner"><span class="split-txt">every webpage to suit your exact needs. Tell us </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="what you want from your website, and we will " class="split-inner"><span class="split-txt">what you want from your website, and we will </span></span></div>
                                    <div class="lqd-lines split-unit lqd-unit-animation-done" style="display: block; text-align: center; position: relative;"><span data-text="make it happen for you. " class="split-inner"><span class="split-txt">make it happen for you. </span></span></div>
                                    </p>
                                    <a href="web-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white lqd-unit-animation-done" style="opacity: 1;"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Web development End-->   
    <!-- UI/UX/Creative/Graphics-->
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_uiux pp-scrollable pp-section" data-anchor="Section-5" style="z-index: 7; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-1" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#444c4f&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/ui-ux-new.gif" alt="Best UI UX Development Company in Gurgaon, India"> </figure>
                                        </div>
                                        <div class="block-revealer__element"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">UI/UX Design</h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech offers businesses cutting-edge graphics and creative design services. Utilizing the most up-to-date tools and design trends, our experienced team produces visually appealing and captivating graphics such as logos, brochures, flyers, and infographics that convey a brand's values and personality while leaving an impactful visual.
                                        Make an impression on your target audience
                                    </p>
                                    <a href="uiux-design.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- UI/UX/Creative/Graphics End-->
    <!-- Digital Marketing start--> 
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_dm pp-scrollable pp-section" data-anchor="Section-6" style="z-index: 6; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#0a0102&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 0;"> <img src="https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExcTkxdnoxMXpncm1paHJxa2prYm5ucDZwZmF0c2d0cG4zcjk2YzR0MiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/gHiRWOaXGGHOY5w6f3/giphy.gif" alt="Best Digital Marketing Company in Gurgaon, India"> </figure>
                                        </div>
                                        <div class="block-revealer__element"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Digital Marketing</h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">Not business stands a chance without Digital Marketing anymore. There are way too many digital marketing companies claiming to be the best. But GrootTech believes in proving it is the best for you. With custom digital marketing plans and organic strategies, we ensure you value for your money. We will ensure that the returns are worth the investment. </p>
                                    <a href="digital-marketing-services.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Digital Marketing End--> 
    <!-- Artificial Intelligence  start--> 
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_ai pp-scrollable pp-section" data-anchor="Section-7" style="z-index: 5; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-4" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#333&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/ai-new.gif" alt="Artificial Intelligence services in Gurgaon"> </figure>
                                        </div>
                                        <div class="block-revealer__element"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Artificial Intelligence</h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech's Artificial Intelligence service offers you the insight your business needs for long-term and immediate success. All pain points in your business are identified by GrootTech's advanced AI systems. GrootTech offers user-friendly AI solutions so that every client can take it for a run. We want you to witness the groundbreaking solutions our AI team offers.  </p>
                                    <a href="artificial-intelligence.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Artificial IntelligenceEnd-->
    <!-- Blockchain Development start--> 
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_bcd pp-scrollable pp-section" data-anchor="Section-8" style="z-index: 4; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-2" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap lqd-promo-reverse text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;rl&quot;, &quot;bgcolor&quot;: &quot;#0996c7&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/blockchain-new.gif" alt=" Reliable Blockchain development
                                                company in Gurgaon"> </figure>
                                        </div>
                                        <div class="block-revealer__element"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Blockchain Development</h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech provides a stable and systematically updated Blockchain infrastructure for cryptocurrency. With GrootTech's independent Blockchain development platform, your cryptocurrency will be safe from censorship and collusion alike. No other Blockchain development company can ensure smooth and safe business with cryptocurrency like GrootTech does.</p>
                                    <a href="blockchain-development.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blockchain development End-->    
    <!-- Big Data start-->  
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_bd pp-scrollable pp-section" data-anchor="Section-9" style="z-index: 3; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(68, 76, 79, 0.1)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#000&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/big-data-new.gif" alt=" Renowned Big Data company in Gurgaon"> </figure>
                                        </div>
                                        <div class="block-revealer__element"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Big Data</h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech's Big Data service helps you accurately analyze bulk data. Our robust infrastructure helps create detailed reports including business metrics analysis. You can analyze all sorts of files and feeds that you upload. Cloud databases, online or offline applications, custom applications, nothing is out of bounds for GrootTech's Big Data company. </p>
                                    <a href="big-data.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Big Data  End--> 
    <!-- Internet of things  start-->  
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_iot pp-scrollable pp-section" data-anchor="Section-10" style="z-index: 2; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#d7f1fb&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/iot-new.gif" alt="IoT services"> </figure>
                                        </div>
                                        <div class="block-revealer__element"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Internet of things</h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech offers IoT services that will introduce your lifestyle to the future. You can initiate smart living with all your devices synced and running on the IoT principle. GrootTech has IoT solutions for every device that is important in your daily routine. Include as many functional devices you want to on your IoT systems. You tell us how much convenience you need and we will serve it to you on a plate. </p>
                                    <a href="iot.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Service</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Internet of things   End-->    
    <!-- Our Clients start--> 
    <section class="vc_row fullheight d-flex flex-wrap align-items-center py-5 py-md-0 bg_clients pp-scrollable pp-section" data-anchor="Section-11" style="z-index: 1; transform: translate3d(0px, 0px, 0px);">
        <div class="lqd-stack-section-inner">
            <div class="lqd-particles-bg-wrap">
                <div class="ld-particles-container">
                    <div class="ld-particles-inner invisible" id="ld-particles-5" data-particles="true" data-particles-options="{&quot;particles&quot;:{&quot;number&quot;:{&quot;value&quot;:6},&quot;color&quot;:{&quot;value&quot;:[&quot;#ffb739&quot;,&quot;#fe045e&quot;,&quot;#3de4a3&quot;,&quot;#aa57ff&quot;]},&quot;shape&quot;:{&quot;type&quot;:[&quot;circle&quot;]},&quot;opacity&quot;:{&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;opacity_min&quot;:0.6,&quot;speed&quot;:1,&quot;sync&quot;:true}},&quot;size&quot;:{&quot;value&quot;:3,&quot;random&quot;:true,&quot;anim&quot;:{&quot;enable&quot;:true,&quot;size_min&quot;:2,&quot;speed&quot;:1}},&quot;move&quot;:{&quot;out_mode&quot;:&quot;out&quot;}},&quot;interactivity&quot;:[]}"> </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="lqd-column col-md-8 col-md-offset-2 mob-margin-tp">
                        <div class="lqd-promo-wrap text-white">
                            <div class="lqd-promo-inner">
                                <div class="lqd-promo-dynamic-shape" data-dynamic-shape="true">
                                    <svg class="scene" width="100%" height="100%" fill="rgba(0, 0, 0, 0.05)" viewBox="0 0 650 650">
                                        <path d="
                                            M616.0065675014151,498.3062292573324 C599.1198413943324,616.8282421570593 497.1438597476801,708 373.8598010013949,708 C253.5808597476801,708 153.5875089597106,621.2127578429407 133.11756750141512,506.92177074266755 C55.92522267037527,475.12139476073105 0,395.6370570647987 0,303.0781879030682 C0,167.76818790306822 109.69,58.07818790306822 245,58.07818790306822 C298.60512957397475,58.07818790306822 347.460719352356,78.37793593105246 383.2806616943409,110.64866756537819 C423.09971935235603,61.12406406894753 485.2841295739747,28.92181209693178 555,28.92181209693178 C690.31,28.92181209693178 800,138.61181209693177 800,273.9218120969318 C800,386.16894293520136 719.9192226703752,479.6982728046471 616.0065675014151,498.3062292573324 Z" pathdata:id="
                                            M717.349,515.468 C693.326,625.562 595.298,708.000 478.000,708.000 C351.735,708.000 247.793,612.479 234.460,489.760 C104.042,484.237 -0.000,376.777 -0.000,245.000 C-0.000,109.690 109.690,-0.000 245.000,-0.000 C330.697,-0.000 406.103,44.009 449.889,110.648 C481.742,95.493 517.376,87.000 555.000,87.000 C690.310,87.000 800.000,196.690 800.000,332.000 C800.000,405.029 768.036,470.582 717.349,515.468 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z;
                                            M565.540,489.760 C552.207,612.479 448.265,708.000 322.000,708.000 C204.702,708.000 106.675,625.562 82.651,515.468 C31.964,470.582 -0.000,405.029 -0.000,332.000 C-0.000,196.690 109.690,87.000 245.000,87.000 C282.624,87.000 318.258,95.493 350.111,110.649 C393.897,44.009 469.303,0.000 555.000,0.000 C690.310,0.000 800.000,109.690 800.000,245.000 C800.000,376.777 695.958,484.238 565.540,489.760 Z"></path>
                                    </svg>
                                </div>
                                <div class="lqd-promo-cat">
                                    <ul class="reset-ul">
                                    </ul>
                                </div>
                                <div class="lqd-promo-img">
                                    <div class="lqd-promo-img-inner block-revealer" data-reveal="true" data-reveal-options="{ &quot;direction&quot;: &quot;lr&quot;, &quot;bgcolor&quot;: &quot;#444661&quot;, &quot;revealSettings&quot;: { &quot;onCoverAnimations&quot;: { &quot;scale&quot;: [2, 1] } } }" style="position: relative;">
                                        <div class="block-revealer__content">
                                            <figure style="opacity: 0;"> <img src="https://ik.imagekit.io/6dcaysirg/akoode-images/clients-new.gif" alt="Clients of GrootTech"> </figure>
                                        </div>
                                        <div class="block-revealer__element"></div>
                                    </div>
                                </div>
                                <div class="lqd-promo-content" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;.btn&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1300, &quot;initValues&quot;: { &quot;translateY&quot;: 70, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">
                                    <h2 class="text-white" data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;chars, words&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 800, &quot;delay&quot;: 70, &quot;initValues&quot;: { &quot;translateX&quot;: 70, &quot;rotateY&quot;: 65, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateX&quot;: 0, &quot;rotateY&quot;: 0, &quot;opacity&quot;: 1 } }">Our Clients</h2>
                                    <p data-split-text="true" data-split-options="{ &quot;type&quot;: &quot;lines&quot; }" data-custom-animations="true" data-ca-options="{ &quot;triggerHandler&quot;: &quot;inview&quot;, &quot;animationTarget&quot;: &quot;all-childs&quot;, &quot;duration&quot;: 800, &quot;startDelay&quot;: 1000, &quot;delay&quot;: 120, &quot;initValues&quot;: { &quot;translateY&quot;: 50, &quot;opacity&quot;: 0 }, &quot;animations&quot;: { &quot;translateY&quot;: 0, &quot;opacity&quot;: 1 } }">GrootTech has built a large portfolio with different industries operating across the globe,our major clients are in North America,Europe and APAC region . Our quality work and end to end solution capabilities help in strengthening the long term partnership with the GrootTech team.</p>
                                    <a href="clients.php" class="btn btn-underlined text-uppercase font-size-12 font-weight-bold ltr-sp-2 color-secondary text-hover-white text-white"> <span> <span class="btn-txt">Explore Clients</span> </span> </a> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Our Clients End-->
</main>
</div>
<!-- Overlay Menu Start Here-->
<div id="myNav" class="overlay">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <div class="overlay-content">
        <!-- Menu Tabs Start here-->
        <div class="menu_box">
            <div class="col-xs-3">
                <!-- required for floating -->
                <!-- Nav tabs -->
                <ul class="nav nav-tabs tabs-left">
                    <li class="active"><a href="#sw" data-toggle="tab">
                        <span class="hidden-xs">Software Development</span> 
                        <i class="flaticon flaticon-computer" title="Software Development"></i>
                        </a>
                    </li>
                    <li><a href="#mad" data-toggle="tab">
                        <span class="hidden-xs">Mobile App Development </span>
                        <i class="flaticon flaticon-app" title="Mobile App Development"></i>
                        </a>
                    </li>
                    <li><a href="#wd" data-toggle="tab">
                        <span class="hidden-xs">Web Development </span>
                        <i class="flaticon flaticon-data" title="Web Development "></i>
                        </a>
                    </li>
                    <li><a href="#uiux" data-toggle="tab">
                        <span class="hidden-xs">Artificial Intelligence </span>
                        <i class="flaticon flaticon-brain" title="UI/UX/Creative/Graphics"></i>
                        </a>
                    </li>
                    <li><a href="#ecd" data-toggle="tab">
                        <span class="hidden-xs">E-Commerce Solutions </span>
                        <i class="flaticon flaticon-monitor" title="E-Commerce Solutions "></i>
                        </a>
                    </li>
                    <li><a href="#Staff" data-toggle="tab">
                        <span class="hidden-xs">Staff Augmentation </span>
                        <i class="flaticon flaticon-monitor" title="Staff Augmentation"></i>
                        </a>
                    </li>
                    <li><a href="#industry" data-toggle="tab">
                        <span class="hidden-xs">Industry </span>
                        <i class="flaticon flaticon-security" title="Industry"></i>
                        </a>
                    </li>
                    <li><a href="#resource" data-toggle="tab">
                        <span class="hidden-xs">Resources  </span>
                        <i class="flaticon flaticon-people" title="Resources"></i>
                        </a>
                    </li>
                    <li><a href="#compinfo" data-toggle="tab">
                        <span class="hidden-xs">Company Info.</span>  
                        <i class="flaticon flaticon-construction" title="Company Info."></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-xs-9">
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="sw">
                        <h2><a href="software-development.php">Software Development</a> </h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="software-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Custom Software <br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="software-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Enterprise <br>Solutions</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="software-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>CRM <br>Solutions</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="mad">
                        <h2><a href="mobile-app-development.php">Mobile App Development</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="https://www.GrootTech.com/ios-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>IOS<br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="https://www.GrootTech.com/android-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Android  <br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="https://www.GrootTech.com/native-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Native  <br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="https://www.GrootTech.com/hybrid-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Hybrid App <br>Development</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="wd">
                        <h2><a href="web-development.php">Web Development</a> </h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="web-development-technology.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Website Development Technologies</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="custom-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Custom Website<br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="dyanamic-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Dynamic Website <br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="static-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Static Website <br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="full-stack-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Full Stack Website<br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="ai-powered-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Ai Powered Website<br>Development</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="uiux">
                        <h2><a href="artificial-intelligence.php">Artificial Intelligence</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="deep-learning.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-data"></i>Deep Learning &amp;<br>Data Science</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="integrated-intelligence-services.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-pencil"></i>Integrated Intelligence<br> Services</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="computer-vision-technology.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-computer"></i>Computer Vision <br>Technology Services</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="3d-and-metaverse-based.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-computer-1"></i>3D and Metaverse-based</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="pioneering-generative-ai-integration.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-security"></i>Generative AI Integration Solutions</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="ecd">
                        <h2><a href="ecommerce-solutions-in-gurgaon.php">E-Commerce Solutions</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="magento-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Magento<br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="opencart-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Opencart<br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="shopify-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Shopify<br>Development</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="woocommerce-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>WooCommerce<br>Development</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="Staff">
                        <h2><a href="staff-augmentation-services.php">Staff Augmentation Services</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="staff-augmentation-services.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Staff<br>Augmentation Services</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="industry">
                        <h2><a href="industry-landing.php">Industry</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	Banking and <br>Finance</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	Tour and <br>Travels </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	Real Estate and <br>Construction  </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	E-Commerce /<br> Retail</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	Automobile</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	Health and <br>Social Care</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	Education and <br>Career </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>	Arts and <br>Entertainment </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="resource">
                        <h2><a href="resources.php">Resources</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="blog">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Blogs</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="resources.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Case Studies</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="compinfo">
                        <h2>Company Information</h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="about.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-construction"></i>About Company</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="clients.php">
                                    <div class="box_1">
                                        <div class="text"><i class="fa fa-group"></i>Our Clients</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="contact.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-email"></i>Get In Touch</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="career.php">
                                    <div class="box_1">
                                        <div class="text"><i class="fa fa-plane"></i>Career</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Menu Tabs End here-->
        </div>
    </div>
</div>
<!-- Overlay Menu Start End-->
<script src="/assets/vendors/modernizr.min.js"></script>
<script src="assets/vendors/jquery.min.js"></script>
<script src="assets/js/theme-vendors.min.js"></script>
<script src="assets/vendors/pagePiling/dist/jquery.pagepiling.min.js"></script>
<script src="assets/js/theme.min.js"></script>
<script src="assets/js/ambi-custom.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/slick.js"></script>
<script src="assets/js/slick-responsive.js"></script>  <a href="https://api.whatsapp.com/send?phone=919917864981" class="whatsapp_btn">
<img src="assets/img/whatsapp.png" alt="whatsapp">
</a>
<style type="text/css">
    .whatsapp_btn{
    position: fixed;bottom: 16px; right: 16px; width: 40px;height: 40px;  
    border-radius: 10px;z-index: 9999;
    -webkit-box-shadow: 3px 3px 6px rgba(0,0,0,0.5);
    -moz-box-shadow: 3px 3px 6px rgba(0,0,0,0.5);
    box-shadow: 3px 3px 6px rgba(0,0,0,0.5);
    -webkit-box-sizing:border-box;
    -moz-box-sizing:border-box;
    -ms-box-sizing:border-box;
    box-sizing:border-box;
    }
    .whatsapp_btn:hover{
    -webkit-box-shadow: 5px 5px 5px rgba(0,0,0,0.5);
    -moz-box-shadow: 5px 5px 5px rgba(0,0,0,0.5);
    box-shadow: 5px 5px 5px rgba(0,0,0,0.5);
    }
    .whatsapp_btn img{display: block;width: auto;max-width: 100%}
    @media (max-width: 767px){
    .whatsapp_btn{display: block;}
    }
</style>
<div class="footer_home">
    <div class="container">
        <div class="row">
            <div class="col-md-4"> 2025 © Copyright Akoode Technology, All Rights Reserved. </div>
            <div class="col-md-6">
                <div class="bottom-social-network" style="
                    float: left;
                    ">
                    <a href="https://www.akoode.com/software-development.php" style="
                        color: #fff;font-weight:bold;
                        ">SOFTWARE DEVELOPMENT | </a> <a href="https://www.akoode.com/mobile-app-development.php" style="
                        color: #fff;font-weight:bold;
                        ">MOBILE APP DEVELOPMENT | </a> <a href="https://www.akoode.com/web-development.php" style="
                        color: #fff;font-weight:bold;
                        ">WEB DEVELOPMENT | </a> <a href="https://www.akoode.com/ecommerce-development-company-gurgaon.php" style="
                        color: #fff;font-weight:bold;
                        ">ECOMMERCE SOLUTIONS</a> <!--| <a href="https://www.akoode.com/staff-augmentation-services.php" style="
                        color: #fff;font-weight:bold;
                        ">STAFF</a>-->
                </div>
            </div>
            <div class="col-md-2">
                <div class="bottom-social-network">
                    <a href="https://www.facebook.com/AkoodeTech" target="_blank"><i class="fa fa-facebook"></i></a> <a href="https://twitter.com/akoodetek" target="_blank"><i class="fa fa-twitter"></i></a> 
                    <!--<a href="https://plus.google.com/u/0/103679943862115086770" target="_blank"><i class="fa fa-google-plus"></i></a>--> 
                    <a href="https://www.youtube.com/channel/UCvAZeGZ9UTQSIe1LXBQTyOQ" target="_blank"><i class="fa fa-youtube"></i></a> <a href="https://www.linkedin.com/company/akoode-technology" target="_blank"><i class="fa fa-linkedin"></i></a> 
                </div>
            </div>
        </div>
    </div>
</div>
<!-- partical js start -->
<!-- <script src="assets/js/app.js"></script> -->
<!-- partical js End -->
<link rel="canonical" href="http://www.akoode.com/">
<script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Akoode Technology",
      "image": "https://www.akoode.com/assets/img/logo-white.png",
      "@id": "",
      "url": "https://www.akoode.com/",
      "telephone": "+91-9917864981",
      "priceRange": "$$",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "412 Vipul Business Park Near Subhash Chowk , Sohna road - Sector 48 Gurgaon 122018, India",
        "addressLocality": "Gurgaon",
        "postalCode": "122018",
        "addressCountry": "IN"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 28.4226457,
        "longitude": 77.0376039
      },
      "openingHoursSpecification": {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday"
        ],
        "opens": "00:00",
        "closes": "23:59"
      } 
    }
</script>
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@context":"https://schema.org","@type":"SiteNavigationElement","@id":"#siteNav","name":"Custom Software Development Company in Gurugram","url":"https://www.akoode.com/"},{"@context":"https://schema.org","@type":"SiteNavigationElement","@id":"#siteNav","name":"Software Development Company","url":"https://www.akoode.com/software-development.php"},{"@context":"https://schema.org","@type":"SiteNavigationElement","@id":"#siteNav","name":"Mobile App Development Company","url":"https://www.akoode.com/mobile-app-development.php"},{"@context":"https://schema.org","@type":"SiteNavigationElement","@id":"#siteNav","name":"Web Development Company","url":"https://www.akoode.com/web-development.php"},{"@context":"https://schema.org","@type":"SiteNavigationElement","@id":"#siteNav","name":"UI/UX/Creative/Graphics","url":"https://www.akoode.com/uiux-design.php"},{"@context":"https://schema.org","@type":"SiteNavigationElement","@id":"#siteNav","name":"E-Commerce Solutions","url":"https://www.akoode.com/ecommerce-solutions-landing.php"}]}</script>
<div class="lqd-stack-prevnext-wrap">
    <button class="lqd-stack-prevnext-button lqd-stack-prev-button">
        <span class="lqd-stack-button-labbel">Previous</span>
        <span class="lqd-stack-button-ext">
            <svg width="36px" height="36px" class="lqd-stack-button-circ" viewBox="0 0 36 36" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000">
                <path d="M17.89548,35.29096 C27.5027383,35.29096 35.29096,27.5027383 35.29096,17.89548 C35.29096,8.28822168 27.5027383,0.5 17.89548,0.5 C8.28822168,0.5 0.5,8.28822168 0.5,17.89548 C0.5,27.5027383 8.28822168,35.29096 17.89548,35.29096 Z"></path>
            </svg>
            <svg width="36px" height="36px" class="lqd-stack-button-circ lqd-stack-button-circ-clone" viewBox="0 0 36 36" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000">
                <path d="M17.89548,35.29096 C27.5027383,35.29096 35.29096,27.5027383 35.29096,17.89548 C35.29096,8.28822168 27.5027383,0.5 17.89548,0.5 C8.28822168,0.5 0.5,8.28822168 0.5,17.89548 C0.5,27.5027383 8.28822168,35.29096 17.89548,35.29096 Z"></path>
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" class="lqd-stack-button-arrow" width="12.5px" height="13.5px" viewBox="0 0 12.5 13.5" fill="none" stroke="#000">
                <path d="M11.489,6.498 L0.514,12.501 L0.514,0.495 L11.489,6.498 Z"></path>
            </svg>
        </span>
    </button>
    <button class="lqd-stack-prevnext-button lqd-stack-next-button">
        <span class="lqd-stack-button-labbel">Next</span>
        <span class="lqd-stack-button-ext">
            <svg width="36px" height="36px" class="lqd-stack-button-circ" viewBox="0 0 36 36" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000">
                <path d="M17.89548,35.29096 C27.5027383,35.29096 35.29096,27.5027383 35.29096,17.89548 C35.29096,8.28822168 27.5027383,0.5 17.89548,0.5 C8.28822168,0.5 0.5,8.28822168 0.5,17.89548 C0.5,27.5027383 8.28822168,35.29096 17.89548,35.29096 Z"></path>
            </svg>
            <svg width="36px" height="36px" class="lqd-stack-button-circ lqd-stack-button-circ-clone" viewBox="0 0 36 36" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#000">
                <path d="M17.89548,35.29096 C27.5027383,35.29096 35.29096,27.5027383 35.29096,17.89548 C35.29096,8.28822168 27.5027383,0.5 17.89548,0.5 C8.28822168,0.5 0.5,8.28822168 0.5,17.89548 C0.5,27.5027383 8.28822168,35.29096 17.89548,35.29096 Z"></path>
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" class="lqd-stack-button-arrow" width="12.5px" height="13.5px" viewBox="0 0 12.5 13.5" fill="none" stroke="#000">
                <path d="M11.489,6.498 L0.514,12.501 L0.514,0.495 L11.489,6.498 Z"></path>
            </svg>
        </span>
    </button>
</div>
<div class="lqd-stack-page-number"><span class="lqd-stack-page-number-counter">
    <span class="lqd-stack-page-number-current">03</span>
    <span class="lqd-stack-page-number-passed">04</span>
    </span><span class="lqd-stack-page-number-total">11</span>
</div>
<div id="cb-connect-sidebar-main">
    <div id="cb-connect-sidebar">
        <a href="#" class="cb-connect-close-sidebar-button">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="currentColor">
                <path fill-rule="evenodd" d="M3.3352346,13.1409137 L3.33523455,13.1409138 C2.91548014,13.5733825 2.92546046,14.2645641 3.35752584,14.684707 C3.78087294,15.0963751 4.45458199,15.0962796 4.87780976,14.6844919 L9.00453522,10.5538595 L13.1373639,14.6904917 L13.1373638,14.6904917 C13.568947,15.1110906 14.2594594,15.1018597 14.6796682,14.6698737 C15.0920236,14.2459591 15.0919517,13.570408 14.6795052,13.1465834 L10.5469491,9.01016937 L14.6955806,4.85777412 L14.6955806,4.85777409 C15.1130468,4.423134 15.0994531,3.73205118 14.6652183,3.31419357 C14.2430237,2.90792372 13.5756331,2.90792372 13.1534407,3.31419361 L9.00453675,7.46620706 L4.86206292,3.31981159 L4.86206295,3.31981162 C4.436122,2.89342832 3.74549844,2.89339123 3.31951335,3.31972975 C2.89352771,3.74606833 2.89349066,4.43733659 3.31943155,4.86371935 L7.46206886,9.01011482 L3.3352346,13.1409137 Z" fill=""></path>
            </svg>
        </a>
        <div id="cb-connect-sidebar-loading">
            <div>
                <div class="cb-connect-sidebar-loading-outer">
                    <div class="cb-connect-sidebar-loading-inner">
                        <img src="chrome-extension://pmnhcgfcafcnkbengdcanjablaabjplo/src/assets/logo.svg" width="40" height="40">
                        <div class="cb-connect-sidebar-loading-inner-text">Loading...</div>
                    </div>
                </div>
            </div>
        </div>
        <div><iframe id="cb-connect-sidebar-iframe" lang="en" class="cb-connect-sidebar-container" style="height: 100vh; min-height: 100vh"></iframe></div>
    </div>
    <div id="cb-connect-open-button-outer" class="cb-connect-open-button-is-tucked" style="inset: 64px 0px auto auto;">
        <div id="cb-connect-open-button-inner" style="background: rgb(20, 140, 252);">
            <img src="chrome-extension://pmnhcgfcafcnkbengdcanjablaabjplo/src/assets/logo-dark-background.svg" width="20" height="20" style="user-select: none;width: 20px !important;height:20px !important;filter: none !important;">
            <div id="cb-connect-open-button-icp-message" style="display: none;">ICP</div>
            <div id="cb-connect-open-button-move-button">
                <svg xmlns="http://www.w3.org/2000/svg" height="20" width="20">
                    <path d="M4 12.5V11h12v1.5ZM4 9V7.5h12V9Z"></path>
                </svg>
            </div>
            <a href="#" id="cb-connect-close-widget-button" title="Hide widget on this site or all sites">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="currentColor">
                    <path fill-rule="evenodd" d="M3.3352346,13.1409137 L3.33523455,13.1409138 C2.91548014,13.5733825 2.92546046,14.2645641 3.35752584,14.684707 C3.78087294,15.0963751 4.45458199,15.0962796 4.87780976,14.6844919 L9.00453522,10.5538595 L13.1373639,14.6904917 L13.1373638,14.6904917 C13.568947,15.1110906 14.2594594,15.1018597 14.6796682,14.6698737 C15.0920236,14.2459591 15.0919517,13.570408 14.6795052,13.1465834 L10.5469491,9.01016937 L14.6955806,4.85777412 L14.6955806,4.85777409 C15.1130468,4.423134 15.0994531,3.73205118 14.6652183,3.31419357 C14.2430237,2.90792372 13.5756331,2.90792372 13.1534407,3.31419361 L9.00453675,7.46620706 L4.86206292,3.31981159 L4.86206295,3.31981162 C4.436122,2.89342832 3.74549844,2.89339123 3.31951335,3.31972975 C2.89352771,3.74606833 2.89349066,4.43733659 3.31943155,4.86371935 L7.46206886,9.01011482 L3.3352346,13.1409137 Z" fill=""></path>
                </svg>
            </a>
        </div>
    </div>
</div>
</body>
</html>
<header class="main-header header-fullscreen header-fullscreen-style-1 main-header-overlay sticky-top">
    <div class="mainbar-wrap">
        <div class="megamenu-hover-bg"></div>
        <div class="container-fluid mainbar-container">
            <div class="mainbar">
                <div class="align-items-lg-stretch">
                    <div class="col">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="" rel="home">
                            <span class="navbar-brand-inner">
                            <span class="navbar-brand-inner"> <img class="logo-default"
                                src="assets/img/logo-white.png"
                                alt="Best Software Development Company in Moradabad"></span>
                            </span>
                            </a>
                            <button type="button" class="navbar-toggle collapsed nav-trigger style-mobile"
                                data-toggle="collapse" data-target="#main-header-collapse" aria-expanded="false"
                                data-changeclassnames='{ "html": "overflow-hidden" }' title="top navigation">
                                <!-- For Mobile Device -->
                                <span class="txt for_mobile">
                                <a href="tel:9917864981" class="phone"><i class="fa fa-phone"></i></a>
                                <a href="mailto:info@grootechsolution.com" class="phone"> <i class="fa fa-envelope"></i></a>
                                </span>
                                <span class="bars" onclick="openNav()">
                                <span class="bar"></span>
                                <span class="bar"></span>
                                <span class="bar"></span>
                                </span>
                                <!-- For Mobile Device -->
                            </button>
                        </div>
                    </div>
                    <div class="col text-right hidden-xs">
                        <div class="header-module">
                            <button
                                class="nav-trigger collapsed style-1 fill-solid scheme-light txt-left main-nav-trigger"
                                role="button" type="button" data-toggle="collapse" data-target="#main-header-collapse"
                                aria-expanded="false" aria-controls="main-header-collapse"
                                data-changeclassnames='{ "html": "overflow-hidden" }'>
                            <span class="bars" onclick="openNav()">
                            <span class="bar"></span>
                            <span class="bar"></span>
                            <span class="bar"></span>
                            </span>
                            <span class="txt">
                            <a href="tel:9917864981" class="phone"><i class="fa fa-phone"></i>
                            +91-9917864981</a>
                            <a href="mailto:info@grootechsolution.com" class="phone"> <i class="fa fa-envelope"></i>
                            info@grootechsolution.com </a>
                            <a href="post-requirement.php" class="visit-btn">Post Requirement</a>
                            </span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Partical Layer Start-->
        <div id="particles-js"></div>
        <!-- Partical Layer End-->
    </div>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Akoode Technologies",
            "url": "",
            "logo": "assets/img/logo-white.png",
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+91-9917864981",
                "contactType": "sales",
                "contactOption": "TollFree",
                "areaServed": "IN",
                "availableLanguage": "en"
            },
            "sameAs": [
                "https://www.facebook.com/AkoodeTech",
                "https://twitter.com/akoodetek",
                "https://www.youtube.com/channel/UCvAZeGZ9UTQSIe1LXBQTyOQ",
                "https://www.linkedin.com/company/akoode-technology"
            ]
        }
    </script>
</header>
<main id="content" class="content bg-black" data-liquid-stack="true"
    data-stack-options='{"navigation":true, "prevNextButtons":false, "pageNumber":true, "effect":"fadeScale"}'>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_sw">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/sw-development-mobile.webp" width="70%"
                            alt=" Customized Software Development Company in Gurgaon">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt"> Software Development</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode Technology, a
                                    leading software development company with offices in Gurgaon, India and the
                                    United States, provides organisations with tailored software, corporate
                                    solutions, CRM solutions and SaaS-based development services. Our experienced
                                    team uses cutting-edge tools and techniques to craft innovative yet
                                    customer-focused software applications for various industries.</span> 
                                </p>
                            </div>
                            <a href="software-development.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_mobapp">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/app-development-mobile.webp" width="70%"
                            alt="App Development Company in Gurgaon">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt"> Mobile App Development</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode's expert
                                    services offer custom development of various mobile applications for all kinds
                                    of OS platforms, such as Android, iOS and Windows. Get your own customized
                                    mobile apps to ensure the success strategy of your business, because these apps
                                    play an effective instrumental role to achieve digital interaction.</span> 
                                </p>
                            </div>
                            <a href="mobile-app-development.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_ecs">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/ecommerce-mobile.webp" width="70%"
                            alt=" Ecommerce Development Company in Gurgaon">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt">eCommerce Solutions</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode offers
                                    e-commerce solutions to maximize your revenues and consumer engagement. We help
                                    you lower your costs and optimize your web presence for the highest possible
                                    return on investment. We do this by building a web presence over multiple
                                    channels and giving you the tools required to understand your target
                                    demographic.</span> 
                                </p>
                            </div>
                            <a href="ecommerce-development-company-gurgaon.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_wd">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/webdevelopment-mobile.webp" width="70%"
                            alt="Custom Web Development Company in Gurgaon">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt">Web Development</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode offers better
                                    web development solution than any exclusive web development company. With our
                                    full range of custom designs, user-friendly web layout, and fluid coding, we
                                    give you the best web development services. We value client reviews and
                                    requirements. We tailor every webpage to suit your exact needs. Tell us what you
                                    want from your website, and we will make it happen for you. </span> 
                                </p>
                            </div>
                            <a href="web-development.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_uiux">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/ui-ux-mobile.webp" width="70%"
                            alt="Best UI UX Development Company in Gurgaon, India">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt">UI/UX Design</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode offers
                                    businesses cutting-edge graphics and creative design services. Utilizing the
                                    most up-to-date tools and design trends, our experienced team produces visually
                                    appealing and captivating graphics such as logos, brochures, flyers, and
                                    infographics that convey a brand's values and personality while leaving an
                                    impactful visual. </span> 
                                </p>
                            </div>
                            <a href="uiux-design.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_dm">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/digital-mobile.webp" width="70%"
                            alt="Best Digital Marketing Company in Gurgaon, India">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt">Digital Marketing</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">No business stands a
                                    chance without Digital Marketing anymore. There are way too many digital
                                    marketing companies claiming to be the best. But Akoode believes in proving it
                                    is the best for you. With custom digital marketing plans and organic strategies,
                                    we ensure you value for your money. We will ensure that the returns are worth
                                    the investment. </span> 
                                </p>
                            </div>
                            <a href="digital-marketing-services.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_ai">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/ai-mobile.webp" width="70%"
                            alt="Artificial Intelligence services in Gurgaon">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt">Artificial Intelligence</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode's Artificial
                                    Intelligence service offers you the insight your business needs for long-term
                                    and immediate success. All pain points in your business are identified by
                                    Akoode's advanced AI systems. Akoode offers user-friendly AI solutions so that
                                    every client can take it for a run. We want you to witness the groundbreaking
                                    solutions our AI team offers. </span> 
                                </p>
                            </div>
                            <a href="artificial-intelligence.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_bcd">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/blockchain-mobile.webp" width="70%"
                            alt=" Reliable Blockchain development company in Gurgaon">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt">Blockchain Development</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode provides a
                                    stable and systematically updated Blockchain infrastructure for cryptocurrency.
                                    With Akoode's independent Blockchain development platform, your cryptocurrency
                                    will be safe from censorship and collusion alike. No other Blockchain
                                    development company can ensure smooth and safe business with cryptocurrency like
                                    Akoode does. </span> 
                                </p>
                            </div>
                            <a href="blockchain-development.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_bd">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/big-data-mobile.webp" width="70%"
                            alt="Renowned Big Data company in Gurgaon">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt">Big Data</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode's Big Data
                                    service helps you accurately analyze bulk data. Our robust infrastructure helps
                                    create detailed reports including business metrics analysis. You can analyze all
                                    sorts of files and feeds that you upload. Cloud databases, online or offline
                                    applications, custom applications, nothing is out of bounds for Akoode's Big
                                    Data company. </span> 
                                </p>
                            </div>
                            <a href="big-data.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_iot">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/iot-mobile.webp" width="70%" alt="IoT services">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt"> Internet of things</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">Akoode offers IoT
                                    services that will introduce your lifestyle to the future. You can initiate
                                    smart living with all your devices synced and running on the IoT principle.
                                    Akoode has IoT solutions for every device that is important in your daily
                                    routine. Include as many functional devices you want to on your IoT systems. You
                                    tell us how much convenience you need and we will serve it to you on a plate.
                                    </span> 
                                </p>
                            </div>
                            <a href="iot.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="vc_row py-5 bg-cover d-flex flex-wrap align-items-center bg_iot">
        <div class="container">
            <div class="row">
                <div class="lqd-column col-lg-12 text-center mb-4">
                    <figure>
                        <img src="assets/img/mobile/clients-mobile.webp" width="70%" alt="Clients of Akoode">
                    </figure>
                </div>
                <div class="lqd-column col-lg-6 text-center">
                    <div class="ld-fancy-heading">
                        <h1 class="h1 lh-85 ltr-sp--05 font-weight-bold text-white heading-small"> <span
                            class="ld-fh-txt"> Our Clients</span> </h1>
                    </div>
                    <div class="row">
                        <div class="lqd-column col-md-12">
                            <div class="ld-fancy-heading mask-text">
                                <p class="mb-3 h5 text-white para-small"> <span class="ld-fh-txt">GrootTech has built a
                                    large portfolio with different industries operating across the globe,our major
                                    clients are in North America,Europe and APAC region . Our quality work and end
                                    to end solution capabilities help in strengthening the long term partnership
                                    with the GrootTech team. </span> 
                                </p>
                            </div>
                            <a href="clients.php"
                                class="btn btn-naked text-uppercase text-white font-size-16 font-weight-bold ltr-sp-1">
                            <span> <span class="btn-txt">Explore Services</span> <span class="btn-icon"><i
                                class="fa fa-angle-right"></i></span> </span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <link rel="canonical" href="mobile-app-development.php" />
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "GrootTech Technologies",
            "image": "assets/img/logo-white.png",
            "@id": "",
            "url": "mobile-app-development.php",
            "telephone": "+91-9917864981",
            "priceRange": "$$",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "412 Buddhi Vihar,Moradabad Uttar Prasdesh 244001 India",
                "addressLocality": "Gurgaon",
                "postalCode": "122018",
                "addressCountry": "IN"
            },
            "geo": {
                "@type": "GeoCoordinates",
                "latitude": 28.4226457,
                "longitude": 77.0376039
            },
            "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                    "Sunday"
                ],
                "opens": "00:00",
                "closes": "23:59"
            }
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org/",
            "@type": "BreadcrumbList",
            "itemListElement": [{
                "@type": "ListItem",
                "position": 1,
                "name": "Home",
                "item": ""
            }, {
                "@type": "ListItem",
                "position": 2,
                "name": "Mobile App Development",
                "item": "mobile-app-development.php"
            }]
        }
    </script>
</main>
<!-- Overlay Menu Start Here-->
<div id="myNav" class="overlay">
    <a href="javascript:void(0)" class="closebtn" onClick="closeNav()">&times;</a>
    <div class="overlay-content">
        <!-- Menu Tabs Start here-->
        <div class="menu_box">
            <div class="col-xs-3">
                <!-- required for floating -->
                <!-- Nav tabs -->
                <ul class="nav nav-tabs tabs-left">
                    <li class="active"><a href="#sw" data-toggle="tab">
                        <span class="hidden-xs">Software Development</span>
                        <i class="flaticon flaticon-computer" title="Software Development"></i>
                        </a>
                    </li>
                    <li><a href="#mad" data-toggle="tab">
                        <span class="hidden-xs">Mobile App Development </span>
                        <i class="flaticon flaticon-app" title="Mobile App Development"></i>
                        </a>
                    </li>
                    <li><a href="#wd" data-toggle="tab">
                        <span class="hidden-xs">Web Development </span>
                        <i class="flaticon flaticon-data" title="Web Development "></i>
                        </a>
                    </li>
                    <li><a href="#uiux" data-toggle="tab">
                        <span class="hidden-xs">Artificial Intelligence </span>
                        <i class="flaticon flaticon-brain" title="UI/UX/Creative/Graphics"></i>
                        </a>
                    </li>
                    <li><a href="#ecd" data-toggle="tab">
                        <span class="hidden-xs">E-Commerce Solutions </span>
                        <i class="flaticon flaticon-monitor" title="E-Commerce Solutions "></i>
                        </a>
                    </li>
                    <li><a href="#Staff" data-toggle="tab">
                        <span class="hidden-xs">Staff Augmentation </span>
                        <i class="flaticon flaticon-monitor" title="Staff Augmentation"></i>
                        </a>
                    </li>
                    <li><a href="#industry" data-toggle="tab">
                        <span class="hidden-xs">Industry </span>
                        <i class="flaticon flaticon-security" title="Industry"></i>
                        </a>
                    </li>
                    <li><a href="#resource" data-toggle="tab">
                        <span class="hidden-xs">Resources </span>
                        <i class="flaticon flaticon-people" title="Resources"></i>
                        </a>
                    </li>
                    <li><a href="#compinfo" data-toggle="tab">
                        <span class="hidden-xs">Company Info.</span>
                        <i class="flaticon flaticon-construction" title="Company Info."></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-xs-9">
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="sw">
                        <h2><a href="software-development.php">Software Development</a> </h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="software-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Custom Software
                                            <br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="software-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Enterprise <br>Solutions
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="software-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>CRM
                                            <br>Solutions
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="mad">
                        <h2><a href="mobile-app-development.php">Mobile App Development</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="ios-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>IOS<br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="android-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Android <br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="native-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Native
                                            <br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="hybrid-app-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Hybrid App
                                            <br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="wd">
                        <h2><a href="web-development.php">Web Development</a> </h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="web-development-technology.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Website Development
                                            Technologies
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="custom-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Custom
                                            Website<br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="dyanamic-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Dynamic
                                            Website <br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="static-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Static Website
                                            <br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="full-stack-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-ux"></i>Full Stack
                                            Website<br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="ai-powered-website-development.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-digital-marketing"></i>Ai Powered
                                            Website<br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="uiux">
                        <h2><a href="artificial-intelligence.php">Artificial Intelligence</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="deep-learning.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-data"></i>Deep Learning
                                            &amp;<br>Data Science
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="integrated-intelligence-services.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-pencil"></i>Integrated
                                            Intelligence<br> Services
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="computer-vision-technology.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-computer"></i>Computer Vision
                                            <br />Technology Services
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="3d-and-metaverse-based.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-computer-1"></i>3D and
                                            Metaverse-based
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="pioneering-generative-ai-integration.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-security"></i>Generative AI
                                            Integration Solutions
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="ecd">
                        <h2><a href="ecommerce-solutions-in-gurgaon.php">E-Commerce Solutions</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="magento-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Magento<br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="opencart-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Opencart<br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="shopify-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Shopify<br>Development
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="woocommerce-development-company-india.php">
                                    <div class="box_1">
                                        <div class="text"><i
                                            class="flaticon flaticon-chart"></i>WooCommerce<br>Development</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="Staff">
                        <h2><a href="staff-augmentation-services.php">Staff Augmentation Services</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="staff-augmentation-services.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Staff<br>Augmentation
                                            Services
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="industry">
                        <h2><a href="industry-landing.php">Industry</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> Banking and
                                            <br>Finance
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> Tour and <br>Travels
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> Real Estate and
                                            <br>Construction 
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> E-Commerce /<br>
                                            Retail
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> Automobile</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> Health and <br>Social
                                            Care
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> Education and
                                            <br>Career 
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="industry.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i> Arts and
                                            <br>Entertainment 
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="resource">
                        <h2><a href="resources.php">Resources</a></h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="blog">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Blogs</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="resources.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-chart"></i>Case Studies</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="compinfo">
                        <h2>Company Information</h2>
                        <div class="row">
                            <div class="col-md-3">
                                <a href="about.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-construction"></i>About Company
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="clients.php">
                                    <div class="box_1">
                                        <div class="text"><i class="fa fa-group"></i>Our Clients</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="contact.php">
                                    <div class="box_1">
                                        <div class="text"><i class="flaticon flaticon-email"></i>Get In Touch</div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="career.php">
                                    <div class="box_1">
                                        <div class="text"><i class="fa fa-plane"></i>Career</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Menu Tabs End here-->
        </div>
    </div>
</div>
<!-- Overlay Menu Start End-->
<script src="assets/vendors/modernizr.min.js"></script>
<script src="assets/vendors/jquery.min.js"></script>
<script src="assets/js/theme-vendors.min.js"></script>
<script src="assets/vendors/pagePiling/dist/jquery.pagepiling.min.js"></script>
<script src="assets/js/theme.min.js"></script>
<script src="assets/js/ambi-custom.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/slick.js"></script>
<script src="assets/js/slick-responsive.js"></script> <a href="https://api.whatsapp.com/send?phone=919917864981"
    class="whatsapp_btn">
<img src="assets/img/whatsapp.png" alt="whatsapp">
</a>
<style type="text/css">
    .whatsapp_btn {
    position: fixed;
    bottom: 16px;
    right: 16px;
    width: 40px;
    height: 40px;
    border-radius: 10px;
    z-index: 9999;
    -webkit-box-shadow: 3px 3px 6px rgba(0, 0, 0, 0.5);
    -moz-box-shadow: 3px 3px 6px rgba(0, 0, 0, 0.5);
    box-shadow: 3px 3px 6px rgba(0, 0, 0, 0.5);
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    -ms-box-sizing: border-box;
    box-sizing: border-box;
    }
    .whatsapp_btn:hover {
    -webkit-box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5);
    -moz-box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5);
    box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5);
    }
    .whatsapp_btn img {
    display: block;
    width: auto;
    max-width: 100%
    }
    @media (max-width: 767px) {
    .whatsapp_btn {
    display: block;
    }
    }
</style>
