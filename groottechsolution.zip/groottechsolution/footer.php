
<div class="footer_home">
    <div class="container">
        <div class="row">
            <div class="col-md-4"> 2025 © Copyright Groot Tech Solution, All Rights Reserved. </div>
            <div class="col-md-6">
                <div class="bottom-social-network" style="
                    float: left;
                    ">
                    <a href="software-development.php" style="
                        color: #fff;font-weight:bold;
                        ">SOFTWARE DEVELOPMENT | </a> <a href="mobile-app-development.php" style="
                        color: #fff;font-weight:bold;
                        ">MOBILE APP DEVELOPMENT | </a> <a href="web-development.php" style="
                        color: #fff;font-weight:bold;
                        ">WEB DEVELOPMENT | </a> <a href="ecommerce-development-company-gurgaon.php" style="
                        color: #fff;font-weight:bold;
                        ">ECOMMERCE SOLUTIONS</a>
                  
                </div>
            </div>
            <div class="col-md-2">
                <div class="bottom-social-network">
                    <a href="#" target="_blank"><i
                        class="fa fa-facebook"></i></a> <a href="#" target="_blank"><i
                        class="fa fa-twitter"></i></a>
                    
                    <a href="#" target="_blank"><i
                        class="fa fa-youtube"></i></a> <a href="#"
                        target="_blank"><i class="fa fa-linkedin"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- partical js start -->
<!-- <script src="assets/js/app.js"></script> -->
<!-- partical js End -->
<link rel="canonical" href="http://www.GrootTech.com/" />
<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "name": "GrootTech Technology",
        "image": "assets/img/logo-white.png",
        "@id": "",
        "url": "",
        "telephone": "+91-9917864981",
        "priceRange": "$$",
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "BUddhi Vihar Delhi Road Moradabad Uttar Pradesh 244001, India",
            "addressLocality": "Moradabad",
            "postalCode": "244001",
            "addressCountry": "IN"
        },
     
        "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": [
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
                "Sunday"
            ],
            "opens": "00:00",
            "closes": "23:59"
        }
    }
</script>
<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@graph": [{
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "@id": "#siteNav",
            "name": "Custom Software Development Company in Gurugram",
            "url": ""
        }, {
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "@id": "#siteNav",
            "name": "Software Development Company",
            "url": "software-development.php"
        }, {
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "@id": "#siteNav",
            "name": "Mobile App Development Company",
            "url": "mobile-app-development.php"
        }, {
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "@id": "#siteNav",
            "name": "Web Development Company",
            "url": "web-development.php"
        }, {
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "@id": "#siteNav",
            "name": "UI/UX/Creative/Graphics",
            "url": "uiux-design.php"
        }, {
            "@context": "https://schema.org",
            "@type": "SiteNavigationElement",
            "@id": "#siteNav",
            "name": "E-Commerce Solutions",
            "url": "ecommerce-solutions-landing.php"
        }]
    }
</script>
</body>
</html>
