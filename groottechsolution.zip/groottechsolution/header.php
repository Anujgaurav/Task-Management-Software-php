<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="theme-color" content="#3ed2a7">
        <link rel="shortcut icon" href="assets/img/logoanu.png">
        <title>Groot Tech solution</title>
        <meta name="description" content="">
        <meta property="og:locale" content="en_US">
        <meta property="og:type" content="website">
        <meta property="og:title" content="">
        <meta property="og:url" content="#">
        <meta property="og:description" content="">
        <meta property="og:image" content="https://www.GrootTech.com//assets/img/sw-development.gif">
        <meta property="og:site_name" content="GrootTech Technology">
        <meta name="twitter:card" content="summary">
        <meta name="twitter:site" content="@GrootTech">
        <meta name="twitter:title" content="Software Company in Moradabad | India | USA">
        <meta name="twitter:description" content="Best software company in India, based out in Moradabad. with certified and experience developers we spans our expertise across CRM, SaaS, system software, utility software, application software, DevOps and AI-powered software solutions. Experience the power of tailored, custom software development that  meets your specific business requirements.">
        <meta name="twitter:image" content="assets/img/sw-development.gif">
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
        <link rel="stylesheet" href="assets/css/themes/multiconcept.css">
        <link rel="stylesheet" href="assets/vendors/liquid-icon/liquid-icon.min.css">
        <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/font/flaticon.css">
        <link rel="stylesheet" href="assets/css/theme-vendors.min.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
        <link rel="stylesheet" href="assets/css/theme.min.css">
        <link rel="stylesheet" href="assets/css/themes/wave.css">
        <link rel="stylesheet" href="assets/css/custom.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet" href="assets/css/slick.css" async="">
        <link rel="stylesheet" href="assets/css/slick-theme.css">
        <script async="" src="https://www.googletagmanager.com/gtag/js?id=G-8W111Y0YG1"></script>
   
    </head>
    <body class="lqd-stack-buttons-style-2 header-style-fullscreen lqd-stack-has-prevnext-buttons lqd-stack-has-page-numbers lqd-stack-effect-enabled lqd-stack-effect-fadeScale overflow-hidden lqd-stack-initiated pp-viewing-Section-3 lqd-stack-active-row-dark" data-mobile-nav-trigger-alignment="right" data-mobile-nav-align="left" data-mobile-nav-style="modern" data-mobile-nav-shceme="gray" data-mobile-header-scheme="gray" data-mobile-nav-breakpoint="1199">
        
        <div id="wrap">
            <header class="main-header header-fullscreen header-fullscreen-style-1 main-header-overlay sticky-top">
                <div class="mainbar-wrap">
                    <div class="megamenu-hover-bg"></div>
                    <div class="container-fluid mainbar-container">
                        <div class="mainbar">
                            <div class="align-items-lg-stretch">
                                <div class="col">
                                    <div class="navbar-header">
                                        <a class="navbar-brand" href="index.php" rel="home"> 
                                        <span class="navbar-brand-inner"> 
                                        <span class="navbar-brand-inner"> <img class="logo-default" src="assets/img/logo-white.png" style="width:20%" alt="Best Software Development Company in Moradabad"></span>
                                        </span>
                                        </a>
                                        <button type="button" class="navbar-toggle collapsed nav-trigger style-mobile mobile-nav-trigger-cloned" data-toggle="collapse" data-target="#main-header-collapse-clone" aria-expanded="false" data-changeclassnames="{ &quot;html&quot;: &quot;overflow-hidden&quot; }" title="top navigation">
                                            <!-- For Mobile Device -->
                                            <span class="txt for_mobile"> 
                                            <a href="tel:9917864981" class="phone"><i class="fa fa-phone"></i></a> 
                                            <a href="mailto:info@groottechsolution.in" class="phone"> <i class="fa fa-envelope"></i></a>                
                                            </span> 
                                            <span class="bars" onclick="openNav()"> 
                                            <span class="bar"></span> 
                                            <span class="bar"></span> 
                                            <span class="bar"></span>
                                            </span>
                                            <!-- For Mobile Device -->
                                        </button>
                                    </div>
                                </div>
                                <div class="col text-right hidden-xs">
                                    <div class="header-module">
                                        <button class="nav-trigger collapsed style-1 fill-solid scheme-light txt-left main-nav-trigger" role="button" type="button" data-toggle="collapse" data-target="#main-header-collapse" aria-expanded="false" aria-controls="main-header-collapse" data-changeclassnames="{ &quot;html&quot;: &quot;overflow-hidden&quot; }"> 
                                        <span class="bars" onclick="openNav()"> 
                                        <span class="bar"></span> 
                                        <span class="bar"></span> 
                                        <span class="bar"></span>
                                        </span> 
                                        <span class="txt"> 
                                        <a href="tel:9917864981" class="phone"><i class="fa fa-phone"></i> +91-9917864981</a> 
                                        <a href="mailto:info@grootechsolution.in" class="phone"> <i class="fa fa-envelope"></i> grootechsolution@gmail.com </a>
                                        <a href="post-requirement.php" class="visit-btn">Post Requirement</a>
                                        </span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Partical Layer Start-->
                    <div id="particles-js"></div>
                    <!-- Partical Layer End-->
                </div>
               
            </header>