jQuery(document).ready(function($) {
    // Code that uses jQuery's $ can follow here.

    // Code that uses other library's $ can follow here.
    $('.newwork-slide ').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });


    $('.feature-slide ').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
    $('.industry-slide ').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
    $('.whychoose-slide').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 2,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
    $('.client-slide').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 4,
        slidesToScroll: 4,
        responsive: [{
            breakpoint: 1024,
            settings: {
                prevArrow: false,
                nextArrow: false,
                slidesToShow: 4,
                slidesToScroll: 2,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 768,
            settings: {
                dots: false,
                prevArrow: false,
                nextArrow: false,
                slidesToShow: 4,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                dots: false,
                prevArrow: false,
                nextArrow: false,
                slidesToShow: 2,
                slidesToScroll: 1
            }
        }]
    });
    $('.videotestimonial').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 4,
        slidesToScroll: 4,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });
    $('.testimonial-slide').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1024,
            settings: {
                prevArrow: false,
                nextArrow: false,
                slidesToShow: 1,
                slidesToScroll: 2,
                infinite: true,
                dots: false
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                prevArrow: false,
                nextArrow: false,
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });


    $('.webdesignportfolio-slide').slick({
        dots: false,
        infinite: false,
        autoplay: true,
        infinite: true,
        prevArrow: false,
        nextArrow: false,
        speed: 800,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 2,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    });

    //===== Pakages Horizontal Scrrol Bar Slider Js Start here ====
    var $slider = $("#pakageslider, #otherpakageslider");
    $slider.on('init', function() {
        mouseWheel($slider);
    }).slick({
        dots: true,
        horozontal: true,
        infinite: false
    });
});

function mouseWheel($slider) {
    //$(window).on('wheel', { $slider: $slider }, mouseWheelHandler);
}

function mouseWheelHandler(event) {
    event.preventDefault();
    var $slider = event.data.$slider;
    var delta = event.originalEvent.deltaY;
    if (delta > 0) {
        $slider.slick('slickPrev');
    } else {
        $slider.slick('slickNext');
    }
}

//otherpakageslider