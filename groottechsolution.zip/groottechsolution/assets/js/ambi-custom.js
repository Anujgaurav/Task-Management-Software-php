// Home Menu Js Start here
function openNav() {
    document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.height = "0%";
}

// Menu Tabs Js Start Here
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

var defaultOpenElement = document.getElementById("defaultOpen");
if (defaultOpenElement) {
    defaultOpenElement.click();
}

var isMobile = false;
if (navigator.userAgent.match(/Android/i) ||
    navigator.userAgent.match(/webOS/i) ||
    navigator.userAgent.match(/iPhone/i) ||
    navigator.userAgent.match(/iPad/i) ||
    navigator.userAgent.match(/iPod/i) ||
    navigator.userAgent.match(/BlackBerry/i) ||
    navigator.userAgent.match(/Windows Phone/i)) {
    isMobile = true;
}
console.log(isMobile);
if (isMobile) {
    window.addEventListener('scroll', function() {
        var sticky = document.querySelector('.sticky-top'),
            scroll = window.pageYOffset;

        if (scroll >= 100) {
            sticky.classList.add('fixed');
        } else {
            sticky.classList.remove('fixed');
        }
    });
}